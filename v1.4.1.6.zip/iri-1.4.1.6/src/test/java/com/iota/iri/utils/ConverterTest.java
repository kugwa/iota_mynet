package com.iota.iri.utils;

import com.iota.iri.hash.Curl;
import com.iota.iri.hash.Kerl;
import com.iota.iri.hash.SpongeFactory;
import com.iota.iri.model.Hash;
import org.junit.Assert;
import org.junit.Test;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Created by paul on 7/25/17.
 */
public class ConverterTest {


}