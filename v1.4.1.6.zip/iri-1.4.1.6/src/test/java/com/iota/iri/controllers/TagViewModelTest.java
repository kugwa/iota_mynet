package com.iota.iri.controllers;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by paul on 5/2/17.
 */
public class TagViewModelTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void getHash() throws Exception {

    }

    @Test
    public void getTransactionHashes() throws Exception {

    }

}