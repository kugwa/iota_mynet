package com.iota.iri;

public enum OsVariants {
    Windows,
    Unix;
}
